#!/usr/bin/env bash
cmd=reset
source scripts/_lib.sh
$cmd
